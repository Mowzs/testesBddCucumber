package pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.everis.beca.CommonsBasePage;

public class FinancingWebmotors extends CommonsBasePage{

	
	WebDriverWait wait;
	Actions builder;
	
	public FinancingWebmotors() {	
		wait = new WebDriverWait(_Driver(), 15);
		builder = new Actions(_Driver());
	}
	
	
	public void validarPaginaDeFinanciamento(String texto) {
		
		assertEquals(_Driver().getTitle(),texto);
		
	}

}
