package pages;

import static org.junit.Assert.assertEquals;


import java.util.ArrayList;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.everis.beca.CommonsBasePage;

public class HomePageWebmotors extends CommonsBasePage {
	
	WebDriverWait wait;
	Actions builder;
	
	
	//instanciando driver e builder de metodos
	public HomePageWebmotors() {
		wait = new WebDriverWait(_Driver(), 15);
		builder = new Actions(_Driver());
	}
	
	//ACESSO A PÁGINA
	public void acessaPaginaHome() {
		navegarAteSite("https://www.webmotors.com.br");
	}
//========================================================================================================
	//ROTINA DE PESQUISA
	public void preencheProduto(String produto){
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"searchBar\"]"))).sendKeys(produto);
	}
	
	public void clicarBotaoPesquisar() {		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"WhiteBox\"]/div[1]/div[2]/div/div/div/div/div/div/a/div[2]"))).click();
	}
//========================================================================================================
	
	//VALIDAR ELEMENTOS EM TELA

	public void validarElementos(ArrayList<String> lista) {	
	
		for(int i=0;i<lista.size();i++) {
			validarElementoEmTela(By.xpath(lista.get(i).toString()));
		}
	}
	
//========================================================================================================
	
	//CliCAR NO BOTÃO QUERO VENDER
	
	public void clicarEmQueroVender(){
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"WhiteBox\"]/div[1]/div[1]/h2[2]/a"))).click();
	}
//=========================================================================================================
	//MUDAR DE ABA
	
	public void mudarParaNovaAba() {		
		alternarAbas("1");	
		}
	
//=========================================================================================================
	//CLICAR NO BOTÃO DO CAROUSEL
/*	
	public void avancarCarouselCategorias(int vezes) {
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"searchBar\"]"))).click();
		builder.sendKeys(Keys.TAB);
		builder.sendKeys(Keys.TAB);
		builder.sendKeys(Keys.TAB);
		for(int i = 0 ; i<vezes;i++) {
			builder.sendKeys(Keys.ARROW_RIGHT);
			;
		}
	}

		
	public void avancarCarouselNaWebmotors(int vezes) {
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/main/div[3]/div[6]/h2"))).isSelected();
		builder.sendKeys(Keys.TAB);
		
		for(int i = 0 ; i<vezes;i++) {
			builder.sendKeys(Keys.ARROW_RIGHT);
			;
		}
	}
*/
	
//==========================================================================================================	
	//VALIDAR HISTÓRICO DE BUSCAS
	public void clicarLogo() {
		clicarElemento(By.xpath("//*[@id=\"logoHomeWebmotors\"]/img"));
	}
	
	
	public void validarHistorico() {
		WebElement buscas = validarElementoEmTela(By.xpath("//*[@id=\"WhiteBox\"]/div[2]"));
		assertEquals(buscas.getText(),"Suas Últimas buscas");
	
	}
//===========================================================================================================
	//CLICAR NO BOTÃO FINANCIAR
	public void clicarBotaoFinanciar(){
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"WhiteBox\"]/div[1]/div[1]/h2[3]/a"))).click();
	}
//===========================================================================================================
	//LOGIN NA PAGINA
	public void acessarBotaoEntrar() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/header/nav/div/ul/li[5]"))).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"userLoginRegister\"]"))).click();
	}
	
	
	public void preencheDadosDeLogin(String email, String senha){
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email"))).sendKeys(email);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("senha"))).sendKeys(senha);
	}
	
	public void clicarBotaoEntrar() {		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"btnEntrar\"]"))).click();
	}
	
	public void validaNomeUsuario(String nome) {
	
		WebElement usuario = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("Menu-User__login")));

		String nomeUsuario = usuario.getText();

		assertEquals(nomeUsuario,nome);
    	
	}
//================================================================================================	
	//ADICIONAR AOS FAVORITOS
	
	public void adicionarFavoritos() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/main/div[1]/div[3]/div[2]/div/div[1]/div/div[1]/div/div[2]/div/div[2]/div"))).click();
	}
	//NAVEGAR PARA FAVORITOS
	public void acessarFavoritos () {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/header/nav/div/ul/div[1]/a"))).click();
	}
	//FECHAR O POP UP DE PRIMEIRO FAVORITO	
	public void fecharPop() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div[1]/div[2]/div/div[1]/button"))).click();
	}
	//O POP UP PEDE PARA FAZER LOGIN E DIRECIONA PARA GARAGEM JÁ LOGADO
	//*[@id=\"root\"]/div[1]/div[2]/div/div[5]/a
//=================================================================================================	
	
	//ACESSAR CADASTRO
	
	public void acessarCadastro() {		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("Menu-User__login"))).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"navigationEditProfile\"]"))).click();
		alternarAbas("1");
	}
	
//=================================================================================================	
	
	
}