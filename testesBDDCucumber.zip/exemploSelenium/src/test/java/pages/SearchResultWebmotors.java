package pages;

import static org.junit.Assert.assertEquals;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.everis.beca.CommonsBasePage;

public class SearchResultWebmotors extends CommonsBasePage{

	WebDriverWait wait;
	Actions builder;
	

//VALIDAÇÃO DE RESULTADO DE BUSCA
	
public SearchResultWebmotors(){
	wait = new WebDriverWait(_Driver(), 15);
	builder = new Actions(_Driver());
}
	
public void validarProduto(String produto) {
		
		WebElement pesquisa = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("volkswagen-jetta")));

		String textoPesquisado = pesquisa.getText();
		String comparar="";
		
		if (textoPesquisado.contains(produto)) {
				comparar = "ok";
	    }
		
		assertEquals("ok", comparar);
	}
		
}
