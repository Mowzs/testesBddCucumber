package pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.everis.beca.CommonsBasePage;

public class UserProfileWebmotors extends CommonsBasePage{

	WebDriverWait wait;
	Actions builder;
	
	public UserProfileWebmotors() {
		
		wait = new WebDriverWait(_Driver(), 15);
		builder = new Actions(_Driver());
	}
	
	public void alterarTelefone() {
		WebElement telefone =wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"app\"]/div/main/div[2]/div/div[2]/div[3]/div/input")));
		
		telefone.click();
		
		for(int i=0;i<=10;i++) {
		telefone.sendKeys(Keys.BACK_SPACE);
		}
		
		int[] tel= {1,1,9,9,8,8,7,7,6,6,4};
		
		//formulario.sendKeys(Keys.TAB);
		for(int x=0;x<tel.length;x++) {
			String n = ""+tel[x];
			telefone.sendKeys(n);
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"app\"]/div/main/div[2]/div/div[2]/div[7]/div/button"))).click();

	}

	public void verificarMensagem() {
		WebElement alterarTel = _Driver().findElement(By.name("telefonePrincipal"));
		assertEquals("(11)99887-7664",alterarTel.getAttribute("value"));
		
	}
	
	
}
