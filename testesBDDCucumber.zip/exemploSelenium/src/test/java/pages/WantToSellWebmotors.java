package pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.everis.beca.CommonsBasePage;

public class WantToSellWebmotors extends CommonsBasePage{

	WebDriverWait wait;
	Actions builder;
	
	public WantToSellWebmotors() {	
		wait = new WebDriverWait(_Driver(), 15);
		builder = new Actions(_Driver());
	}
	
	public void validarPaginaQueroVender(String texto) {
			
		WebElement pesquisa = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("section__title")));
		String textoPesquisado = pesquisa.getText();
		String comparar="";
		
		if (textoPesquisado.contains(texto)) {
				comparar = "ok";
	    }
		
		assertEquals("ok", comparar);
	}
}
