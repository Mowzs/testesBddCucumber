package stepDefinitions;

import io.cucumber.java.pt.*;
import pages.*;


public class CT001_PesquisaTestsSteps {
	
HomePageWebmotors pesquisaProduto = new HomePageWebmotors();
SearchResultWebmotors resultadoPesquisa = new SearchResultWebmotors();
	
	@Dado("que eu navego até a página inicial do webmotors")
	public void navegarAteHomePage(){
		pesquisaProduto.acessaPaginaHome();
	}
	
	@Quando("eu preencho o campo de buscas")
	public void preenchoDadosBusca() {
		pesquisaProduto.preencheProduto("Jetta");
	}
	
	@E("clico no botão de busca")
	public void clicarBuscar() {
		pesquisaProduto.clicarBotaoPesquisar();
	}
	
	@Entao("eu efetuei a pesquisa do produto")
	public void verificarPagina() {
		resultadoPesquisa.validarProduto("JETTA");
	}
	
	
}