package stepDefinitions;

import java.util.ArrayList;

import io.cucumber.java.pt.*;
import pages.HomePageWebmotors;



public class CT002_ValidarElementosMenuTestsSteps {
	
HomePageWebmotors validarMenu = new HomePageWebmotors();
	
	@Então("verifico os elementos do Menu")
	public void verificarMenu() {
		ArrayList<String>listaMenu = new ArrayList<String>();
		
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/li[1]");
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/li[2]");
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/li[3]");
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/li[4]");
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/li[5]/div[1]/img");
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/div[1]/a");
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/div[2]/a");
		listaMenu.add("//*[@id=\"root\"]/header/nav/div/ul/div[3]/div[1]");
		validarMenu.validarElementos(listaMenu);
		
	}
	
	
}