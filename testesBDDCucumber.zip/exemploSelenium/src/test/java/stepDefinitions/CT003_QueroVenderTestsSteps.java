package stepDefinitions;

import io.cucumber.java.pt.*;

import pages.*;

public class CT003_QueroVenderTestsSteps {
	
HomePageWebmotors home = new HomePageWebmotors();
WantToSellWebmotors queroVender = new WantToSellWebmotors();	

	@Quando("clico em quero vender")
	public void clicarQueroVender() {
		home.clicarEmQueroVender();;
	}
	
	@E("mudo para a aba que abriu")
	public void alternarPaginas() {
		home.alternarAbas("1");
	}
	
	@Entao("eu acessei a página de vendas")
	public void verificarPagina() {
		queroVender.validarPaginaQueroVender("Anuncie na Webmotors e venda");
	}
	
	
}