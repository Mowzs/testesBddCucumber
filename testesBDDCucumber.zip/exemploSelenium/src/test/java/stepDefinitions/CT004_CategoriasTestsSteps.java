package stepDefinitions;

import java.util.ArrayList;
import io.cucumber.java.pt.*;
import pages.HomePageWebmotors;


public class CT004_CategoriasTestsSteps {
	
HomePageWebmotors categorias = new HomePageWebmotors();
	@Entao("eu verifiquei os itens na área de categorias")
	public void verificarPagina() {
		
		//validar elementos visiveis
		ArrayList<String>listaMenu = new ArrayList<String>();
		
		listaMenu.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[1]/div/div/div/a");
		listaMenu.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[2]/div/div/div/a");
		listaMenu.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[3]/div/div/div/a");
		listaMenu.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[4]/div/div/div/a");
		listaMenu.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[5]/div/div/div/a");
		listaMenu.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[6]/div/div/div/a");
		categorias.validarElementos(listaMenu);
	
	/*		
		//avancar carousel
		categorias.avancarCarouselCategorias(4);
	
		//validar elementos que surgem
		ArrayList<String>listaMenu2 = new ArrayList<String>();
		
		listaMenu2.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[7]/div/div/div/a");
		listaMenu2.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[8]/div/div/div/a");
		listaMenu2.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[9]/div/div/div/a");
		listaMenu2.add("//*[@id=\"home_categories_carousel\"]/div/div/div/div/div[10]/div/div/div/a");
		
	
		categorias.validarElementos(listaMenu2);
	*/
	}
	
}