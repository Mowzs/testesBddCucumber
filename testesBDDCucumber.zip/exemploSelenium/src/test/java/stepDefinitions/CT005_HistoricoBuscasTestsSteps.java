package stepDefinitions;

import io.cucumber.java.pt.*;

import pages.HomePageWebmotors;

public class CT005_HistoricoBuscasTestsSteps {
	
HomePageWebmotors historicoBuscas = new HomePageWebmotors();

	
	
	@E("clico no Logo no canto esquerdo superior da página")
	
	public void clicarNoLogoTipo() {
		historicoBuscas.clicarLogo();
	}
	
	@Entao("eu retorno para a página inicial e verifiquei o histórico de buscas")
	public void verificarPagina() {
		historicoBuscas.validarHistorico();
	}
	
	
}