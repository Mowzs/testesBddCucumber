package stepDefinitions;

import io.cucumber.java.pt.*;

import pages.FinancingWebmotors;
import pages.HomePageWebmotors;


public class CT006_FinanciarTestsSteps{

HomePageWebmotors home = new HomePageWebmotors();	
FinancingWebmotors financiar = new FinancingWebmotors();

	
	@Quando("clico em financiar")
	public void clicarFinanciar() {
		home.clicarBotaoFinanciar();
	}
	
	
	@Entao("eu acessei a página de financiamento")
	public void verificarPagina() {
		financiar.validarPaginaDeFinanciamento("Financiamento de Veículos: Saiba + e veja parcelas | Webmotors");
	}
	
	
}