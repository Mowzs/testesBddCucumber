package stepDefinitions;

import io.cucumber.java.pt.*;
import pages.HomePageWebmotors;

public class CT007_LoginTestsSteps {

	HomePageWebmotors login = new HomePageWebmotors();
	
	
	@Quando ("clico no botão entrar e depois em Logar ou Cadastrar")
	public void clicarEmEntrar() {
		login.acessarBotaoEntrar();
	}
	
	@E ("eu preencho os meus dados")
	public void preenchoDados() {
		login.preencheDadosDeLogin("wellferreira@gmail.com", "we2801");
	}
	
	@E("clico no botão entrar")
	public void clicarEntrar() {
		login.clicarBotaoEntrar();
	}
	
	@Entao("eu estou logado")
	public void verificarPagina() {
		login.validaNomeUsuario("Antonio Sales Ferreira");
	}
	
	
}
