package stepDefinitions;

import java.util.ArrayList;

import io.cucumber.java.pt.*;
import pages.HomePageWebmotors;


	public class CT008_BotoesFinalPaginaTestsSteps {
		
	HomePageWebmotors home = new HomePageWebmotors();

		
		@Então("verifico os elementos do final da página")
			public void botoesFinaldaPagina() {
				
				//validar elementos visiveis
				ArrayList<String>listaMenu = new ArrayList<String>();
				
				listaMenu.add("//*[@id=\"CarouselProductsWeb\"]/div/div/div/div/div[1]/div/div/a");
				listaMenu.add("//*[@id=\"CarouselProductsWeb\"]/div/div/div/div/div[2]/div/div/a");
				listaMenu.add("//*[@id=\"CarouselProductsWeb\"]/div/div/div/div/div[3]/div/div/a");
				listaMenu.add("//*[@id=\"CarouselProductsWeb\"]/div/div/div/div/div[4]/div/div/a");
				listaMenu.add("//*[@id=\"CarouselProductsWeb\"]/div/div/div/div/div[5]/div/div/a");
				home.validarElementos(listaMenu);
			/*	
				//avancar carousel
				home.avancarCarouselNaWebmotors(2);
				//validar elementos que surgem
				ArrayList<String>listaMenu2 = new ArrayList<String>();
				
				listaMenu2.add("//*[@id=\"CarouselProductsWeb\"]/div/div/div/div/div[6]/div/div/a");
				listaMenu2.add("//*[@id=\"CarouselProductsWeb\"]/div/div/div/div/div[7]/div/div/a");
				
				home.validarElementos(listaMenu2);
			*/	
		}
		
	}
	

