package stepDefinitions;

import io.cucumber.java.pt.*;
import pages.FavoritesWebmotors;
import pages.HomePageWebmotors;


public class CT009_AddFavoritosTestsSteps {
	
HomePageWebmotors home = new HomePageWebmotors();
FavoritesWebmotors favoritos = new FavoritesWebmotors();
		
	@E("adiciono o primeiro produto ao favoritos")
	public void adicionarFavoritos(){
		home.adicionarFavoritos();
		try {
			home.fecharPop();
		}catch(Exception e) {}
	}
	
	@Entao("eu acesso os meus favoritos e verifiquei o produto na lista")
	public void verificarProdutosFavoritos() {
		home.acessarFavoritos();
		favoritos.verificarFavoritos("JETTA");
	}
	
	
}