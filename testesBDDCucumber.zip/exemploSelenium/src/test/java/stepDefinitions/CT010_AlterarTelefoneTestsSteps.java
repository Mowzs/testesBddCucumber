package stepDefinitions;

import io.cucumber.java.pt.*;
import pages.HomePageWebmotors;
import pages.UserProfileWebmotors;


public class CT010_AlterarTelefoneTestsSteps {
	
HomePageWebmotors home = new HomePageWebmotors();
UserProfileWebmotors usuario = new UserProfileWebmotors();	
	
	@E("acesso o perfil de usuário")
	public void entrarNoCadastro() {
		home.acessarCadastro();
	}
	
	@E("altero o telefone cadastrado")
	public void adicionarFavoritos(){
		usuario.alterarTelefone();
	}
	
	@Entao("eu verifiquei a mensagem de alteração feita com sucesso")
	public void verificarPagina() {
		usuario.verificarMensagem();
		
	}
	
	
}